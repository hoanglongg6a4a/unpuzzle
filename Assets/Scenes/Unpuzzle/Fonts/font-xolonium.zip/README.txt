Xolonium Font
Copyright (C) 2011-2012 Severin Meyer <sev.ch@web.de>

This font is free software. You can use, modify and/or redistribute it
under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 2 of the license, or any later version.

As a special exception, if you create a document which uses this font,
and embed this font or unaltered portions of this font into the document,
this font does not by itself cause the resulting document to be covered by
the GNU General Public License. This exception does not however invalidate
any other reasons why the document might be covered by the GNU General
Public License. If you modify this font, you may extend this exception
to your version of the font, but you are not obligated to do so. If you
do not wish to do so, delete this exception statement from your version.

This font is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this font. If not, see <http://www.gnu.org/licenses/>.
